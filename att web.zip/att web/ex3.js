//Peça ao usuário para digitar os três lados de um triângulo.
//Verifique se os lados formam um triângulo válido (a soma de dois lados deve ser maior que o terceiro).
//Classifique o triângulo como equilátero, isósceles ou escaleno.
// terminar

const frm = document.querySelector("form");
const resposta = document.querySelector("h2");

frm.addEventListener("submit", (e) => {
    e.preventDefault();
    const valor1= Number(frm.inValor1.value);
    const valor2= Number(frm.inValor2.value);
    const valor3= Number(frm.inValor3.value);
    const s1 = (valor1 + valor2)
    const s2 = (valor1 + valor3)
    const s3 = (valor2 + valor3)

    if( s1 > valor3 || s2  > valor2 || s3 > valor1 ){
        if(valor1 == valor2 || valor2 == valor3){
            resposta.innerText = `O triangulo é equilátero`
        }
        if(valor1 == valor2 && valor1 != valor3|| valor1 == valor3 && valor1 != valor2 || valor2 == valor3 && valor2 != valor1){
            resposta.innerText = `O triangulo é isósceles`
        }
        if(valor1 != valor2 && valor2 != valor3){
            resposta.innerText = `O triangulo é escaleno`
        }
    }
    resposta.style.color = "red";
});