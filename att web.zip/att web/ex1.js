//Utilize o operador módulo (%) para verificar se o número é par ou ímpar.
//Exiba uma mensagem informando o resultado.
const frm = document.querySelector("form");
const resposta = document.querySelector("h2");

frm.addEventListener("submit", (e) => {
    e.preventDefault();
    const valor1= frm.inValor1.value;
    
    if (valor1 %2 == 0){
        resposta.innerText = `O número ${valor1} é par`
    }if(valor1 %2 != 0){
        resposta.innerText = `O número ${valor1} é impar`
    }
    resposta.style.color = "blue";
});