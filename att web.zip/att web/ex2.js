//Peça ao usuário para digitar três notas.
//Calcule a média aritmética.
//Utilize estruturas condicionais para verificar se o aluno foi aprovado, reprovado ou está em recuperação.

const frm = document.querySelector("form");
const resposta = document.querySelector("h2");

frm.addEventListener("submit", (e) => {
    e.preventDefault();
    const valor1= Number(frm.inValor1.value);
    const valor2= Number(frm.inValor2.value);
    const valor3= Number(frm.inValor3.value);
    const media = (valor1 + valor2 + valor3)/3; 
    if (media >= 7){
        resposta.innerText = `O aluno esta aprovado com média ${media}.`
    }if(media >= 4){
        resposta.innerText = `O aluno esta em recuperação com media ${media}`
    }if(media < 3.9){
        resposta.innerText = `O aluno reprovado`
    }
    resposta.style.color = "blue";
});