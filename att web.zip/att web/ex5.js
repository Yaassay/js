// Peça ao usuário para digitar seu peso e altura.
// Calcule o Índice de Massa Corporal (IMC).
// Utilize estruturas condicionais para classificar o IMC de acordo com a tabela da OMS.
const frm = document.querySelector("form");
const resposta = document.querySelector("h2");

frm.addEventListener("submit", (e) => {
    e.preventDefault();
    const valor1= parseFloat(frm.inValor1.value);
    const valor2= parseFloat(frm.inValor2.value);
    imc = valor1 / (valor2*valor2)
    if (imc < 18.5) {
        resposta.innerText = `Magreza`;
    } else if (imc < 25) {
        resposta.innerText = `Normal`;
    } else if (imc < 30) {
        resposta.innerText = `Sobrepeso`;
    } else {
        resposta.innerText = `Obesidade`;
    }
});