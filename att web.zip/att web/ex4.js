//Peça ao usuário para digitar sua idade.
//Exiba uma mensagem informando se ele é maior ou menor de idade.
const frm = document.querySelector("form");
const resposta = document.querySelector("h2");

frm.addEventListener("submit", (e) => {
    e.preventDefault();
    const valor1= frm.inValor1.value;
    
    if (valor1 < 18){
        resposta.innerText = `O usuario é menor de idade`
    }if(valor1 > 18){
        resposta.innerText = `O usuario é maior de idade`
    }
    resposta.style.color = "black";
});